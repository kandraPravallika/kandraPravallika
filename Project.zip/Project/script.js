// var selectedSeats = [];

// function bookTickets() {
//   var movieSelect = document.getElementById("movieSelect");
//   var selectedMovie = movieSelect.options[movieSelect.selectedIndex].text;
  
//   if (selectedSeats.length === 0) {
//     document.getElementById("statusText").innerText = "Please select at least one seat.";
//     return;
//   }
  
//   var seatNumbers = selectedSeats.join(", ");
  
//   document.getElementById("statusText").innerText = "Booking confirmed for Movie: " + selectedMovie + ", Seats: " + seatNumbers + ".";
  
//   // Additional logic for booking confirmation, saving data, etc.
// }

// function toggleSeat(seat) {
//   if (selectedSeats.includes(seat)) {
//     selectedSeats = selectedSeats.filter(s => s !== seat);
//     seat.classList.remove("selected");
//   } else {
//     selectedSeats.push(seat);
//     seat.classList.add("selected");
//   }
// }

// document.addEventListener("DOMContentLoaded", function() {
//   var seatMap = document.getElementById("seatMap");
  
//   // Generate seat map dynamically
//   for (var i = 1; i <= 5; i++) {
//     for (var j = 1; j <= 6; j++) {
//       var seat = document.createElement("div");
//       seat.classList.add("seat");
//       seat.innerText = i + "-" + j;
      
//       seat.addEventListener("click", function() {
//         toggleSeat(this);
//       });
      
//       seatMap.appendChild(seat);
//     }
//   }
// });
