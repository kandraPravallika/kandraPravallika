document.getElementById("paymentForm").addEventListener("submit", function(event) {
    event.preventDefault();
    processPayment();
  });
  
  function processPayment() {
    var quantity = document.getElementById("quantity").value;
    var snackOptions = document.querySelectorAll('input[type="checkbox"]:checked');
    var paymentOption = document.getElementById("paymentOption").value;
  
    var totalPrice = calculateTotalPrice(quantity, snackOptions);
    var paymentMessage = "Payment successful! Amount: Rs" + totalPrice.toFixed(2) + "<br>";
    paymentMessage += "Payment option: " + paymentOption;
  
    document.getElementById("paymentResult").innerHTML = paymentMessage;
  }
  
  function calculateTotalPrice(quantity, snackOptions) {
    var ticketPrice = document.getElementById("price").value;
    var snackPrice = 55;
    var totalPrice = quantity * ticketPrice;
  
    snackOptions.forEach(function(snack) {
      totalPrice += snackPrice;
    });
  
    return totalPrice;
 function navigateToHomepage() {
        window.location.href = "home.html";
        setTimeout(navigateToHomepage, 2000);
    }
  }